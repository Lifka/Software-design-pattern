/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoriaAbstracta;

/**
 *
 * @author lifka
 */
public class Prueba {
    
    
    public static void main(String[] args) {
        Cliente.getInstacia().setFactoria(new FactoriaProductoA());
        Cliente.getInstacia().hacerTrabajo();
        
        Cliente.getInstacia().setFactoria(new FactoriaProductoB());
        Cliente.getInstacia().hacerTrabajo();
        
        
    }
    
}
