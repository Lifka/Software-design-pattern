/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoriaAbstracta;


public class Cliente {
    
    // Singleton
    static Cliente instancia = new Cliente();
    
    private Cliente(){}
    
    public static Cliente getInstacia(){
        return instancia;
    }
    
    // Factoría Abstracta
    private FactoriaAbstracta factoria;
    
    void setFactoria(FactoriaAbstracta factoria){
        this.factoria = factoria;
    }
    
    void hacerTrabajo(){
        factoria.crearProducto().getInfo();
    }
    
    
}
